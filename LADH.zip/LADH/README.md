# LADH
Matlab code for "Label distribution guided hashing for cross-modal retrieval" TKDD, accpeted.

run main.m

This is a demo for "Label distribution guided hashing for cross-modal retrieval".
